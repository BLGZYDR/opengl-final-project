#ifndef TEXTURE_H
#define TEXTURE_H

#include <GL/glut.h>

// ����ID����
extern GLuint woodTexture, brickTexture, darkWoodTexture,
marbleTexture, dirtTexture, groundTexture, riverTexture, carpetTexture;

// �������غ����ɺ���
void loadTextures();
void generateWoodTexture();
void generateBrickTexture();
void generateDarkWoodTexture();
void generateMarbleTexture();
void generateDirtTexture();
void generateGroundTexture();
void generateRiverTexture();
void generateCarpetTexture();

// ����Ӧ�ú���
void applyWoodTexture();
void applyBrickTexture();
void applyDarkWoodTexture();
void applyMarbleTexture();
void applyDirtTexture();
void applyGroundTexture();
void applyRiverTexture();
void applyCarpetTexture();
void disableTexture();

#endif