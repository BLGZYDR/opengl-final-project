#include "house.h"
#include "headers.h"
#include "geometry.h"
#include "texture.h"
#include <iostream>

void drawHouse() {
    // �������صػ�
    glPushMatrix();
    applyDirtTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(40, 40, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons1(-1, -10, -1, 802, 19, 802);
    build();
    disableTexture();
    glPopMatrix();

    // ��������ǽ��
    glPushMatrix();
    applyWoodTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);

    // ���Ӻ�ǽ
    cons2(320, 10, 100, 80, 160, 10);
    build2();
    cons2(480, 10, 100, -80, 160, 10);
    build2();

    // ����ǰǽ
    cons4(320, 90, 385, 90, 385, 155, 260, 10);
    build4();
    cons4(480, 90, 415, 90, 415, 155, 260, 10);
    build4();
    cons4(385, 155, 415, 155, 400, 170, 260, 10);
    build4();
    cons1(385, 90, 260, 30, 10, 10);
    build();
    cons1(385, 130, 260, 30, 25, 10);
    build();
    cons1(320, 10, 260, 20, 80, 10);
    build();
    cons1(460, 10, 260, 20, 80, 10);
    build();
    cons1(340, 10, 260, 30, 40, 10);
    build();
    cons1(430, 10, 260, 35, 40, 10);
    build();
    cons1(370, 10, 260, 15, 70, 10);
    build();
    cons1(415, 10, 260, 15, 70, 10);
    build();
    cons1(340, 80, 260, 140, 10, 10);
    build();
    cons1(385, 70, 260, 30, 10, 10);
    build();

    // ������ǽ
    cons2(320, 80, 100, 10, 20, 160);
    build2();
    cons1(320, 10, 100, 10, 70, 70);
    build();
    cons1(320, 10, 200, 10, 70, 60);
    build();
    cons1(320, 10, 170, 10, 40, 30);
    build();

    // ������ǽ
    cons2(480, 80, 110, -10, 20, 150);
    build2();
    cons1(480, 10, 110, -10, 70, 60);
    build();
    cons1(480, 10, 200, -10, 70, 60);
    build();
    cons1(480, 10, 170, -10, 40, 30);
    build();

    disableTexture();
    glPopMatrix();

    // ���Ʒ���
    glPushMatrix();
    applyBrickTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons3(400, 170, 400, 180, 310, 80, 310, 90, 95, 180);
    build3();
    cons3(400, 170, 400, 180, 490, 80, 490, 90, 95, 180);
    build3();

    // �����̴�
    cons2(350, 140, 170, -20, -40, 20);
    build2();
    disableTexture();
    glPopMatrix();

    // ���ƴ���
    glPushMatrix();
    applyDarkWoodTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons1(385, 20, 260, 30, 50, 5);
    build();
    disableTexture();

    // �������ϵ�װ��
    glColor3f(GRAY);
    cons1(390, 25, 265, 20, 2, 0.5);
    build();
    cons1(390, 65, 265, 20, -2, 0.5);
    build();
    cons1(390, 44, 265, 20, 2, 0.5);
    build();
    cons1(390, 25, 265, 2, 40, 0.5);
    build();
    cons1(408, 25, 265, 2, 40, 0.5);
    build();

    // ������ǰ������
    glPushMatrix();
    applyBrickTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons3(400, 95, 400, 85, 370, 65, 370, 55, 270, 70);
    build3();
    cons3(400, 95, 400, 85, 430, 65, 430, 55, 270, 70);
    build3();
    cons1(375, 10, 330, 4, 57, 4);
    build();
    cons1(425, 10, 330, -4, 57, 4);
    build();
    disableTexture();
    glPopMatrix();

    applyMarbleTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);

    // ���������ߵ�
    cons1(385, 10, 260, 30, 10, 60);
    build();
    cons1(375, 10, 270, 10, 10, 50);
    build();
    cons1(415, 10, 270, 10, 10, 50);
    build();

    // ������ߵ�Χ��
    for (int i = 0; i < 6; i++) {
        cons1(378, 20, 270 + i * 10, 4, 30, 4);
        build();
    }
    cons1(378, 50, 270, 4, 4, 58);
    build();

    // �����ұ�Χ��
    for (int i = 0; i < 6; i++) {
        cons1(418, 20, 270 + i * 10, 4, 30, 4);
        build();
    }
    cons1(418, 50, 270, 4, 4, 58);
    build();

    // ����̨��
    cons1(375, 10, 320, 50, 10, 10);
    build();
    cons1(385, 10, 330, 30, 5, 10);
    build();

    // ���Ʒ��ӵذ�
    cons1(325, 10, 105, 150, 10, 150);
    build();

    // ������Χ��Ե
    cons1(315, 10, 95, 170, 10, 5);
    build();
    cons1(315, 10, 100, 5, 10, 175);
    build();
    cons1(485, 10, 100, -5, 10, 175);
    build();
    cons1(320, 10, 270, 65, 10, 5);
    build();
    cons1(480, 10, 270, -65, 10, 5);
    build();

    // �����̴Ѷ�����Ե
    cons1(355, 145, 165, -30, -10, 5);
    build();
    cons1(355, 145, 190, -30, -10, 5);
    build();
    cons1(355, 145, 170, -5, -10, 20);
    build();
    cons1(330, 145, 170, -5, -10, 20);
    build();

    disableTexture();
    glPopMatrix();

    // ���Ʒ����ڲ�װ��
    // ���ƴ��̴���
    glPushMatrix();
    applyWoodTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(40, 40, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons1(330, 20, 110, 30, 20, 3);
    build();
    cons1(330, 20, 113, 30, 10, 60);
    build();
    disableTexture();
    glPopMatrix();

    // ���Ʊ���
    glColor3f(WHITE);
    cons1(330, 30, 113, 30, 10, 15);
    build();
    glColor3f(RED);
    cons1(330, 30, 128, 30, 10, 45);
    build();

    // ����ɳ��
    // ���Ƶ���
    glColor3f(WHITE);
    cons1(470, 30, 150, -30, 10, 60);
    build();
    cons1(470, 40, 150, -5, 12, 60);
    build();

    // ����ľ�Ƶ���
    glPushMatrix();
    applyWoodTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(40, 40, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons1(470, 20, 140, -30, 30, 10);
    build();
    cons1(470, 20, 210, -30, 30, 10);
    build();
    cons1(470, 20, 140, -30, 10, 80);
    build();
    disableTexture();
    glPopMatrix();

    // ���Ƽ���
    glPushMatrix();
    applyDarkWoodTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    cons1(470, 20, 220, -30, 2, 40);
    build();
    cons1(470, 40, 220, -30, 2, 40);
    build();
    cons1(470, 60, 220, -30, 2, 40);
    build();
    cons1(470, 20, 220, -30, 42, 2);
    build();
    cons1(470, 20, 258, -30, 42, 2);
    build();
    disableTexture();
    glPopMatrix();

    // ���Ƶ�̺
    glPushMatrix();
    applyCarpetTexture();
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glMatrixMode(GL_TEXTURE);
    glLoadIdentity();
    glScalef(10, 10, 1.0);
    glMatrixMode(GL_MODELVIEW);
    cons1(340, 20, 120, 130, 1, 130);
    build();
    disableTexture();
    glPopMatrix();

    // ���ƴ�������
    glColor4f(WHITE, 0.2);
    // ���洰��1
    cons1(320, 50, 170, 10, 30, 30);
    build();
    // ���洰��2
    cons1(480, 50, 170, -10, 30, 30);
    build();
    // ���洰��3
    cons1(385, 100, 260, 30, 30, 10);
    build();
    // ���洰��
    cons1(340, 50, 260, 30, 30, 10);
    build();
    // ���洰��
    cons1(430, 50, 260, 30, 30, 10);
    build();

    // ���ƴ����߿�
    glColor3f(BROWN);
    // ���洰���߿�1
    cons1(380, 95, 270, 40, 5, 1);
    build();
    cons1(380, 130, 270, 40, 5, 1);
    build();
    cons1(380, 100, 270, 5, 30, 1);
    build();
    cons1(415, 100, 270, 5, 30, 1);
    build();
    cons1(399, 100, 270, 2, 30, 1);
    build();

    // ���洰���߿�2
    cons1(335, 45, 270, 40, 5, 1);
    build();
    cons1(335, 80, 270, 40, 5, 1);
    build();
    cons1(335, 50, 270, 5, 30, 1);
    build();
    cons1(370, 50, 270, 5, 30, 1);
    build();
    cons1(354, 50, 270, 2, 30, 1);
    build();

    // ���洰���߿�3
    cons1(425, 45, 270, 40, 5, 1);
    build();
    cons1(425, 80, 270, 40, 5, 1);
    build();
    cons1(425, 50, 270, 5, 30, 1);
    build();
    cons1(460, 50, 270, 5, 30, 1);
    build();
    cons1(444, 50, 270, 2, 30, 1);
    build();

    // ���洰���߿�
    cons1(320, 45, 165, -1, 5, 40);
    build();
    cons1(320, 85, 165, -1, -5, 40);
    build();
    cons1(320, 50, 170, -1, 30, -5);
    build();
    cons1(320, 50, 205, -1, 30, -5);
    build();
    cons1(320, 50, 184, -1, 30, 2);
    build();

    // ���洰���߿�
    cons1(481, 45, 165, -1, 5, 40);
    build();
    cons1(481, 85, 165, -1, -5, 40);
    build();
    cons1(481, 50, 170, -1, 30, -5);
    build();
    cons1(481, 50, 205, -1, 30, -5);
    build();
    cons1(481, 50, 184, -1, 30, 2);
    build();
}